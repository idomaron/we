<?PHP

/*-----------------------------------------------------------------------------------*/
/*	Start Form Submit
/*-----------------------------------------------------------------------------------*/

header("Content-type: application/json");

// Setup WPDB
require_once("../../../../wp-config.php");
global $wpdb;

// Vars
$email = $wpdb->escape($_POST['email']);
$agree = $wpdb->escape($_POST['agree']);
$download = $wpdb->escape(base64_decode($_POST['id']));
$ip = $wpdb->escape($_SERVER['REMOTE_ADDR']);
$time = date( 'Y-m-d H:i:s' );
$return_error = 'false';

// Check for valid email
if( is_email($email) ){

	if( $agree == '1' ){

		// Get Options
		$freebiesub_googl_enabled = get_option('freebiesub-googl-enabled');
		$freebiesub_api_key = get_option('freebiesub-api-key');
		$freebiesub_penalty = get_option('freebiesub-penalty');
		$freebiesub_subscribe_heading = get_option('freebiesub-subscribe-heading');
		$freebiesub_subscribe_message = get_option('freebiesub-subscribe-message');
		$freebiesub_optin_message = get_option('freebiesub-optin-message');
		$freebiesub_download_message = get_option('freebiesub-download-message');
		$freebiesub_email_message = get_option('freebiesub-email-message');
		
		// Configure key
		if($freebiesub_api_key == '' || !isset($freebiesub_api_key) ){
			$freebiesub_api_key = NULL;
		}
		
		// Setup URL
		$baseUrl = FREEBIESUB_LOCATION . '/inc/download.php?1='.base64_encode($download).'&2='.base64_encode($email).'';
		if($freebiesub_googl_enabled == 'true'){
			
			$sendUrl = freebiesub_googl($baseUrl, $freebiesub_api_key);
			
		} else {
			
			$sendUrl = $baseUrl;
			
		}
		
		// Sendmail
		$admin_email = get_bloginfo('admin_email');
		$admin_name = get_bloginfo('name');
		$subject = 'You\'re Download Link';
		$headers = 'From: '.$admin_name.' <'.$admin_email.'>' . "\r\n";
		//$message = nl2br($freebiesub_email_message);
		$message = "Hey there,\n\nHere is the download link you requested:\n\n$sendUrl\n\nAfter clicking this link you will not need to enter your email address anymore on the site.\n\nThanks again and enjoy :)";
		mail($email, $subject, $message, $headers);
		
		// Set Waiting Cookie With Penalty Time
		$wait = time() + ( $freebiesub_penalty * 60 );
		setcookie("wpfsubdl", 'waiting', $wait, "/");	
		
		// Return Success
		$return_msg = '<span class="freebiesub-success">Thank you! You will get an email shortly (within 10 minutes or so) with your download link. You will no longer have to enter your email address to download.</span>';
		
	} else {
		
		// Return no opt-in error
		$return_msg = '<span class="freebiesub-error">You must check that you agree to receive our newsletter before downloading.</span>';
		$return_error = 'true';
		
	}

} else {
	
	// return bad email error
	$return_msg = '<span class="freebiesub-error">Whoa There! That email address is not valid.</span>';
	$return_error = 'true';
	
} // end if email valid





/*-----------------------------------------------------------------------------------*/
/*	Return to Frontend
/*-----------------------------------------------------------------------------------*/

$return = array('message' => $return_msg, 'error' => $return_error);
echo json_encode($return);





/*-----------------------------------------------------------------------------------*/
/*	Make URL Short
/*-----------------------------------------------------------------------------------*/

function freebiesub_googl($long, $apiKey = NULL){
	
	$parameters = '{"longUrl": "' . $long . '"}';
	$url = 'https://www.googleapis.com/urlshortener/v1/url';
	
	if (!is_null($apiKey)) {
		$url .= '?key=' . $apiKey;
	}

	$curl = curl_init();
	curl_setopt($curl, CURLOPT_SSLVERSION, 3);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
	curl_setopt($curl, CURLOPT_HEADER, false);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_POST, true);
	curl_setopt($curl, CURLOPT_POSTFIELDS, $parameters);
	curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
	curl_setopt($curl, CURLOPT_URL, $url);
	$data = json_decode(curl_exec($curl));
	curl_close($curl);
	
	return $data->id;
	
}

?>