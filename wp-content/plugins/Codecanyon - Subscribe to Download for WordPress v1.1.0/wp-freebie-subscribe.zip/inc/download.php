<?PHP

// setup
require_once("../../../../wp-config.php");
global $wpdb;
$wpdb->show_errors();

$download = $wpdb->escape( base64_decode($_GET['1']) );
$email = $wpdb->escape( base64_decode($_GET['2']) );
$ip = $wpdb->escape($_SERVER['REMOTE_ADDR']);
$time = date( 'Y-m-d H:i:s' );

// Quick Local Clean of IP
if($ip == '::1'){$ip = '127.0.0.1';}

// Check if user already in DB
$check = $wpdb->get_var($wpdb->prepare("SELECT COUNT(id) FROM ".$wpdb->prefix."freebie_subscriber WHERE email = '$email'"));

// Only insert if not already in db
if($check == 0){

	$wpdb->insert($wpdb->prefix.'freebie_subscriber', array(
		'email'	=> $email,
		'time'	=> $time,
		'ip'	=> $ip 
	));
			
}

// Create cookie for user          
setcookie("wpfsubdl", 'true', time()+31536000, "/");

// redirect to download
header("Location: $download");

?>