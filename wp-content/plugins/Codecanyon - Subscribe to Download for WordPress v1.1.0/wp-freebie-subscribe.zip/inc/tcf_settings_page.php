<?PHP

/*-----------------------------------------------------------------------------------*/
/*	Menu Creation
/*-----------------------------------------------------------------------------------*/

function freebiesub_create_menu() {
	
	// Create Top Level Menu
	$page = add_menu_page( "Freebie Subscribe to Download", "Subscribe To DL", "administrator", __FILE__, "freebiesub_settings_page", FREEBIESUB_LOCATION.'/images/null.png');
	$page2 = add_submenu_page( __FILE__, "Manage Subscribers", "Manage Subscribers", "administrator", "freebiesub_manage_page", "freebiesub_manage_page" );
	
	// Adds the tab into the options panel in WordPress Admin area
	//$page = add_options_page("Aweber Traffic Pop Settings", "Aweber Traffic Pop", 'administrator', __FILE__, 'freebiesub_settings_page');
		
	//call register settings function
	add_action( 'admin_init', 'freebiesub_register_settings' );
		
	// Hook style sheet loading
	add_action( 'admin_print_styles-' . $page, 'freebiesub_settings_admin_cssloader' );
	add_action( 'admin_print_styles-' . $page2, 'freebiesub_settings_admin_cssloader' );
	
}

function freebiesub_nav_css(){ // Add CSS Hor Classy Hover Button :)
	?>
	<style type="text/css" media="screen">
		#toplevel_page_wp-freebie-subscribe-inc-tcf_settings_page div.wp-menu-image { background:transparent url("<?php echo FREEBIESUB_LOCATION.'/images/menu-icon.png'; ?>") no-repeat center center;}
		#toplevel_page_wp-freebie-subscribe-inc-tcf_settings_page:hover div.wp-menu-image,
		#toplevel_page_wp-freebie-subscribe-inc-tcf_settings_page.wp-has-current-submenu div.wp-menu-image
		{ background:transparent url("<?php echo FREEBIESUB_LOCATION.'/images/menu-icon-hover.png'; ?>") no-repeat center center; }	
	</style>
	<?php
}
		



		
/*-----------------------------------------------------------------------------------*/
/*	Add Admin CSS
/*-----------------------------------------------------------------------------------*/

function freebiesub_settings_admin_css(){
				
	/* Register our stylesheet. */
	wp_register_style( 'freebiesubSettings', FREEBIESUB_LOCATION.'/css/tc_framework.css' );
							
} function freebiesub_settings_admin_cssloader(){
	
	// It will be called only on your plugin admin page, enqueue our stylesheet here
	wp_enqueue_style( 'freebiesubSettings' );
	   
}





/*-----------------------------------------------------------------------------------*/
/*	Register Settings
/*-----------------------------------------------------------------------------------*/

function freebiesub_register_settings(){
		
	// Register our settings
	register_setting( 'tcsocialslider-settings-group', 'freebiesub-googl-enabled' );
	register_setting( 'tcsocialslider-settings-group', 'freebiesub-api-key' );
	register_setting( 'tcsocialslider-settings-group', 'freebiesub-penalty' );
	register_setting( 'tcsocialslider-settings-group', 'freebiesub-subscribe-heading' );
	register_setting( 'tcsocialslider-settings-group', 'freebiesub-subscribe-message' );
	register_setting( 'tcsocialslider-settings-group', 'freebiesub-optin-message' );
	register_setting( 'tcsocialslider-settings-group', 'freebiesub-download-message' );
	register_setting( 'tcsocialslider-settings-group', 'freebiesub-email-message' );

	// Apply default options to settings
	add_option( 'freebiesub-googl-enabled', 'true' );
	add_option( 'freebiesub-penalty', '3' );
	add_option( 'freebiesub-subscribe-heading', 'Want this freebie? Enter your email and get it now!' );
	add_option( 'freebiesub-subscribe-message', "Simply enter your email address and the download link will be sent right to your inbox." );
	add_option( 'freebiesub-optin-message', "YES! Please send me the occasional newsletter with exclusive freebies and content. Your email will never be shared, unsubscribe at any time." );
	add_option( 'freebiesub-download-message', "It looks like you're already a reader :)" );
	add_option( 'freebiesub-email-message', "Hey there,\n\nHere is the download link you requested:\n\n$sendUrl\n\nAfter clicking this link you will not need to enter you're email address anymore on the site.\n\nThanks again and enjoy :)");

}





/*-----------------------------------------------------------------------------------*/
/*	Ajax save callback
/*-----------------------------------------------------------------------------------*/

add_action('wp_ajax_freebiesub_tc_settings_save', 'freebiesub_tc_settings_save');

function freebiesub_tc_settings_save(){

	check_ajax_referer('freebiesub_settings_secure', 'security');
	
        // Save the posted value in the database
		update_option('freebiesub-googl-enabled', $_POST['freebiesub-googl-enabled']);
		update_option('freebiesub-api-key', $_POST['freebiesub-api-key']);
		update_option('freebiesub-penalty', $_POST['freebiesub-penalty']);
		update_option('freebiesub-subscribe-heading', $_POST['freebiesub-subscribe-heading']);
		update_option('freebiesub-subscribe-message', $_POST['freebiesub-subscribe-message']);
		update_option('freebiesub-optin-message', $_POST['freebiesub-optin-message']);
		update_option('freebiesub-download-message', $_POST['freebiesub-download-message']);
		
}





/*-----------------------------------------------------------------------------------*/
/*	New framework settings page
/*-----------------------------------------------------------------------------------*/

function freebiesub_settings_page() {

?>

<script>
	
jQuery(document).ready(function(){

/*-----------------------------------------------------------------------------------*/
/*	Options Pages and Tabs
/*-----------------------------------------------------------------------------------*/
	  
	jQuery('.options_pages li').click(function(){
		
		var tab_page = 'div#' + jQuery(this).attr('id');
		var old_page = 'div#' + jQuery('.options_pages li.active').attr('id');
		
		// Change button class
		jQuery('.options_pages li.active').removeClass('active');
		jQuery(this).addClass('active');
				
		// Set active tab page
		jQuery(old_page).fadeOut('slow', function(){
			
			jQuery(tab_page).fadeIn('slow');
			
		});
		
	});
	
/*-----------------------------------------------------------------------------------*/
/*	Form Submit
/*-----------------------------------------------------------------------------------*/
	
	jQuery('form#plugin-options').submit(function(){
			
		var data = jQuery(this).serialize();
		
		jQuery.post(ajaxurl, data, function(response){
			
			if(response == 0){
				
				// Flash success message and shadow
				var success = jQuery('#success-save');
				var bg = jQuery("#message-bg");
				success.css("position","fixed");
				success.css("top", ((jQuery(window).height() - 65) / 2) + jQuery(window).scrollTop() + "px");
				success.css("left", ((jQuery(window).width() - 257) / 2) + jQuery(window).scrollLeft() + "px");
				bg.css({"height": jQuery(window).height()});
				bg.css({"opacity": .45});
				bg.fadeIn("slow", function(){
					success.fadeIn('slow', function(){
						success.delay(1500).fadeOut('fast', function(){
							bg.fadeOut('fast');
						});
					});
				});
								
			} else {
				
				//error out
				
			}
		
		});
				  
		return false;
	
	});	
	
/*-----------------------------------------------------------------------------------*/
/*	Finished
/*-----------------------------------------------------------------------------------*/
	
});

</script>

<div id="message-bg"></div>
<div id="success-save"></div>

<div id="tc_framework_wrap">

	<div id="header">
    	<h1>Subscribe To Download<a href="<?PHP echo FREEBIESUB_LOCATION; ?>/documentation" target="_blank">&raquo; View Plugin Documentation</a></h1>
        <span class="icon">&nbsp;</span>
        <br class="clear" />
    </div>
    
    <div id="content_wrap">
    
    	<form id="plugin-options" name="plugin-options" action="/">
        <?php settings_fields( 'freebiesub-settings-group' ); ?>
        <input type="hidden" name="action" value="freebiesub_tc_settings_save" />
        <input type="hidden" name="security" value="<?php echo wp_create_nonce('freebiesub_settings_secure'); ?>" />
        
        	<div id="sub_header" class="info">
            
                <input type="submit" name="settingsBtn" id="settingsBtn" class="button-framework save-options" value="<?php _e('Save All Changes') ?>" />
                <span>Options Page</span>
                
            </div>
            
            <div id="content">
            
            	<div id="options_content">
                
                	<ul class="options_pages">
                    	<li id="general_options" class="active"><a href="#">General Settings</a><span></span></li>
                    	<li id="template_options"><a href="#">Edit Templates</a><span></span></li>
                    </ul>
                    
                    <div id="general_options" class="options_page">
                    
                    	<div class="option">
                        	<h3>Use Short Links In Emails</h3>
                            <div class="section">
                            	<div class="element"><select name="freebiesub-googl-enabled" id="freebiesub-googl-enabled" class="textfield">
                    <option value="true" <?PHP if(get_option('freebiesub-googl-enabled') == 'true'){echo 'selected="selected"';} ?>>Enabled</option>
                    <option value="false" <?PHP if(get_option('freebiesub-googl-enabled') == 'false'){echo 'selected="selected"';} ?>>Disabled</option>
                				</select></div>
                                <div class="description">Enable this feature to use short URLs, this hides the URL structure and much cleaner for sending in emails.</div>
                            </div>
                        </div>
                        
                        
                    	<div class="option">
                        	<h3>Goo.gl API Key</h3>
                            <div class="section">
                            	<div class="element"><input class="textfield" name="freebiesub-api-key" type="text" id="freebiesub-api-key" value="<?php echo get_option('freebiesub-api-key'); ?>" /></div>
                                <div class="description">Enter an optional goo.gl API key. This is not required to shorten links but you can enter one if you have one.</div>
                            </div>
                        </div>


                    	<div class="option">
                        	<h3>Fake Email Penalty</h3>
                            <div class="section">
                            	<div class="element"><input class="textfield" name="freebiesub-penalty" type="text" id="freebiesub-penalty" value="<?php echo get_option('freebiesub-penalty'); ?>" /></div>
                                <div class="description">Enter the number of minuets users should wait if they entered a fake email they could not verify. Default is 3.</div>
                            </div>
                        </div>
                                                                                                
                    </div>            


                    <div id="template_options" class="options_page hide">     
                    
                    	<div class="option">
                        	<h3>Subscribe Heading</h3>
                            <div class="section">
                            	<div class="element"><input class="textfield" name="freebiesub-subscribe-heading" type="text" id="freebiesub-subscribe-heading" value="<?php echo get_option('freebiesub-subscribe-heading'); ?>" /></div>
                                <div class="description">Enter the heading text that appears if the user has not subscribed yet.</div>
                            </div>
                        </div>


                    	<div class="option">
                        	<h3>Subscribe Message</h3>
                            <div class="section">
                            	<div class="element"><textarea class="textfield" name="freebiesub-subscribe-message" cols="" rows="5" id="freebiesub-subscribe-message"><?php echo get_option('freebiesub-subscribe-message'); ?></textarea></div>
                                <div class="description">Enter the message that will appear if the user has not subscribed yet.</div>
                            </div>
                        </div>


                    	<div class="option">
                        	<h3>Opt-In Message</h3>
                            <div class="section">
                            	<div class="element"><textarea class="textfield" name="freebiesub-optin-message" cols="" rows="5" id="freebiesub-optin-message"><?php echo get_option('freebiesub-optin-message'); ?></textarea></div>
                                <div class="description">Enter the opt-in / checkbox message in the subscribe area.</div>
                            </div>
                        </div>
                        
                        
                    	<div class="option">
                        	<h3>Download Message</h3>
                            <div class="section">
                            	<div class="element"><input class="textfield" name="freebiesub-download-message" type="text" id="freebiesub-download-message" value="<?php echo get_option('freebiesub-download-message'); ?>" /></div>
                                <div class="description">Enter the download message that appears when the user has been verified.</div>
                            </div>
                        </div>
                                                                        
                    </div>            
                                        
            		<br class="clear" />
                    
            </div>
            
            <div class="info bottom">
            
                <input type="submit" name="settingsBtn" id="settingsBtn" class="button-framework save-options" value="<?php _e('Save All Changes') ?>" />
            
            </div>
            
        </form>
        
    </div>

</div>

<?php } ?>