<?PHP

/*-----------------------------------------------------------------------------------*/
/*	Install Database
/*-----------------------------------------------------------------------------------*/

function freebiesub_db_install(){
	
	// define needed globals
	global $wpdb;
	global $freebiesub_db_version;

	// create table
	$table_name = $wpdb->prefix . "freebie_subscriber";
	$sql = "CREATE TABLE ".$table_name." (
		`id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, 
		`email` VARCHAR(250) NOT NULL, 
		`ip` VARCHAR(250) NOT NULL, 
		`time` DATETIME NOT NULL
	) ENGINE = MyISAM;";

	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	dbDelta($sql);
	
	// store db version
	add_option("freebiesub_db_version", "1.0");
	
}





/*-----------------------------------------------------------------------------------*/
/*	Start JS Loader
/*-----------------------------------------------------------------------------------*/
	
// This will make sure all of the JS is only called once!
function freebiesub_jsloader() {
	
	// Make sure we are not in the admin section
	if (!is_admin() & get_option('freebiesub-enabled') != 3) {

		// Root wp-content path
		$root = get_bloginfo('wpurl')."/wp-content";
		
		// Flush the JS
		//wp_deregister_script('jquery');

		// Register them with fresh calls
		//wp_register_script('jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js', false, '1.6.1', false);

		// Include them
		wp_enqueue_script('jquery');
		
		// Run Traffic Pop Theme
		wp_deregister_style('freebieCSS');
		wp_register_style('freebieCSS', FREEBIESUB_LOCATION.'/css/freebiesub.css');
		wp_enqueue_style('freebieCSS');
		
	}
	
	// Bootsrtap MCE
	freebiesub_mce();
	
}





/*-----------------------------------------------------------------------------------*/
/*	Handle Form Submit
/*-----------------------------------------------------------------------------------*/

function freebiesub_form_hooks(){ ?>

	<script type="text/javascript">jQuery(document).ready(function(){jQuery(".freebie-sub-form").submit(function(){var a=jQuery(this),e=a.serialize(),c=a.children("div.replaceArea"),d=c.children("div.replaceArea-error");jQuery(".form-download-button");d.html("");jQuery('input[type="submit"]',a).val("Sending...");jQuery.ajax({type:"POST",url:"<?PHP echo FREEBIESUB_LOCATION; ?>/inc/submit.php",data:e,success:function(b){"true"==b.error?(d.html(b.message),jQuery('input[type="submit"]',a).val("Download")):c.html(b.message)}});return!1});});</script>
	
<?PHP }





/*-----------------------------------------------------------------------------------*/
/*	Start Running Hooks
/*-----------------------------------------------------------------------------------*/

// Installer
register_activation_hook( FREEBIESUB_PATH.'/wp-freebie-subscribe.php', 'freebiesub_db_install' );
// Add the short code to WordPress
add_shortcode("freebiesub", "freebiesub_handle");
// Add hook to include settings CSS
add_action( 'admin_init', 'freebiesub_settings_admin_css' );
// create custom plugin settings menu
add_action( 'admin_menu', 'freebiesub_create_menu' );
// Admin Nav Styles
add_action( 'admin_head', 'freebiesub_nav_css' );
// JS Loader
add_action( 'init', 'freebiesub_jsloader' );
// Form Submit
add_action( 'wp_footer', 'freebiesub_form_hooks' );

?>