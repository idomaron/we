<?PHP

/*-----------------------------------------------------------------------------------*/
/*	Add tinyMCE Button
/*-----------------------------------------------------------------------------------*/

function freebiesub_mce(){
	
	// Don't bother doing this stuff if the current user lacks permissions
	if ( ! current_user_can('edit_posts') && ! current_user_can('edit_pages') )
	return;
	
	// Add only in Rich Editor mode
	if( get_user_option('rich_editing') == 'true'){
		
		// Add cutom button to TinyMCE
		add_filter('mce_external_plugins', "freebiesub_mce_register");
		add_filter('mce_buttons', 'freebiesub_add_button', 0);
		
	}
	
}
function freebiesub_add_button($buttons) {
   array_push($buttons, "separator", "freebiesubplugin");
   return $buttons;
}
function freebiesub_mce_register($plugin_array) {
   $plugin_array['freebiesubplugin'] = FREEBIESUB_LOCATION."/mce/mce_button.js";
   return $plugin_array;
} // end tinyMCE





/*-----------------------------------------------------------------------------------*/
/*	Shortcode Handler
/*-----------------------------------------------------------------------------------*/

function freebiesub_handle($atts, $content) {
	
	// Extract variables from shortcode tag, set defaults
	extract(shortcode_atts(array(
		"download" => '',
	), $atts));
	
	if($download != ''){
						
		return freebiesub_create_form($download);
		
	} else {
		
		return '<!-- download link not set! -->';
		
	} // end if download set
											
}// End shortcode handler





/*-----------------------------------------------------------------------------------*/
/*	Generate Download Form
/*-----------------------------------------------------------------------------------*/

function freebiesub_create_form($download){
	
	// Set Vars
	$cookie = $_COOKIE['wpfsubdl'];
	$freebiesub_googl_enabled = get_option('freebiesub-googl-enabled');
	$freebiesub_api_key = get_option('freebiesub-api-key');
	$freebiesub_penalty = get_option('freebiesub-penalty');
	$freebiesub_subscribe_heading = stripslashes_deep( get_option('freebiesub-subscribe-heading') );
	$freebiesub_subscribe_message = stripslashes_deep( get_option('freebiesub-subscribe-message') );
	$freebiesub_optin_message = stripslashes_deep( get_option('freebiesub-optin-message') );
	$freebiesub_download_message = stripslashes_deep( get_option('freebiesub-download-message') );
	
	if( $cookie == 'waiting' ){
	
	$return = '
	
    <div class="freebie-sub-box">
    
        <div class="freebie-sub-inner">
        
            <h3>Hey! Did You Check Your Email?</h3>
            <p>You have already requested a download and the link has been sent to the email you entered. Please note it can take a few minuets for the email to show up (check all your email folders!) Once you click your link you will not have to enter your email for download links anymore. Nice!</p><br />
            
            <p>Note - If you entered a fake email you can try again in '.$freebiesub_penalty.' minutes with a real one ;)</p>
                        
        </div>
        
    </div>
	
    ';
    
 } elseif( $cookie == 'true' ){
	 
	 $return = '

    <div class="freebie-sub-box">
    
        <div class="freebie-sub-inner">
        
            <h3>'.$freebiesub_download_message.' <input type="button" onclick="window.location=\''.$download.'\'" value="Download" class="freebie-submit download"></h3>
                        
        </div>
        
    </div>

	';
    
	} else {
		
	$return = "

    <div class=\"freebie-sub-box\">
    
        <div class=\"freebie-sub-inner\">
        
            <h3>$freebiesub_subscribe_heading</h3>
            <p>$freebiesub_subscribe_message</p>
            
            <form class=\"freebie-sub-form\">
            
                <div class=\"replaceArea\">
                
                	<div class=\"replaceArea-error\"></div>
                    
                    <center>
                    <input type=\"text\" onblur=\"if(this.value=='')this.value='Email Address';\" onfocus=\"if(this.value=='Email Address')this.value='';\" value=\"Email Address\" name=\"email\" class=\"name\">
                    
                    <input type=\"submit\" value=\"Download\" class=\"freebie-submit\">
                    </center>
                    
                    <label><input class=\"agree\" type=\"checkbox\" checked=\"checked\" value=\"1\" name=\"agree\"><span>$freebiesub_optin_message</span></label>
                    
                    <input type=\"hidden\" name=\"id\" id=\"id\" value=\"".base64_encode($download)."\">
                    
                </div>
                
            </form>
            
        </div>
        
    </div>
	
	";

	} // end if
	
	return $return;
	
} // end main ?>