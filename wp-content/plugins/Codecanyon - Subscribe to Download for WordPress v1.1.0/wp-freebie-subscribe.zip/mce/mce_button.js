function tinyplugin() {
	
	// Retrun plugin value to tinyMCE
    return "[freebiesub-plugin]";
	
}

// Start Tiny MCE plugin
(function() {

    tinymce.create('tinymce.plugins.freebiesubplugin', {

		// When initiated:
        init : function(ed, url){
			
			// Create dialog command
			ed.addCommand('freebiesub-shortcode', function() {
				ed.windowManager.open({
				  file : url + '/mce_button_dialog.php',
				  width : 450,
				  height : 200,
				  inline : 1
				}, {
				  plugin_url : url
				});
			});
			
			// Add the like locker button to the toolbar
            ed.addButton('freebiesubplugin', {
                title : 'Freebie Subscriber',
				cmd : 'freebiesub-shortcode',				
                image: url + "/tinymce.png"
            }); // end addbutton
			
        },

		// Set MCE plugin info
        getInfo : function() {
			
            return {
				
                longname : 'FreebieSubscriber',
                author : 'Tyler Colwell',
                authorurl : 'http://tyler.tc',
                infourl : 'http://tyler.tc',
                version : "1.0"
				
            };
			
        } // end set info
		
    }); // End main plugin init

	// Finally add functionality to toolbar
    tinymce.PluginManager.add('freebiesubplugin', tinymce.plugins.freebiesubplugin);
    
})(); // end plugin