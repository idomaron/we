<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Subscribe to Download</title>
<style type="text/css">

label{
	display:block;
	margin:10px 0px 5px 0px;
	color:#21759B;
	font-family:Arial, Helvetica, sans-serif;
	font-weight:bold;
	font-size:13px;
	background:url(../images/mce-gear.png) left center no-repeat;
	line-height:20px;
	padding:0 0 0 24px;
}

.input{
	width:395px;
    background: none repeat scroll 0 0 #F3F3F3;
    border: 1px solid #DDDDDD;
    color: #333333;
    padding: 6px;
	margin:5px 0px 10px 0px;
	font-size:11px;
}

#ltd-insert{
	padding:7px 11px;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border-radius: 4px;
	font-weight:bold;
    background: none repeat scroll 0 0 #F3F3F3;
    border: 1px solid #DDDDDD;
    color: #999999 !important;
	font-size:12px;
	cursor:pointer;
}

#ltd-insert:hover{
	border:1px solid #bbbbbb;
	color:#666666 !important;
}

</style>
<link href="../../../../wp-includes/js/thickbox/thickbox.css" rel="stylesheet" type="text/css" />
<script language="javascript" src="../../../../wp-includes/js/jquery/jquery.js"></script>
<script language="javascript" src="../../../../wp-includes/js/thickbox/thickbox.js"></script>
<script language="javascript" src="../../../../wp-includes/js/tinymce/tiny_mce_popup.js"></script>
<script language="javascript" src="../../../../wp-includes/js/tinymce/utils/mctabs.js"></script>
<script language="javascript" src="../../../../wp-includes/js/tinymce/utils/form_utils.js"></script>
<script language="javascript" type="text/javascript">

	jQuery(document).ready(function() {
	
		jQuery('#upload_image_button').click(function() {
			 formfield = jQuery('#upload_image').attr('name');
			 tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
			 return false;
		});
		
		window.send_to_editor = function(html) {
			 imgurl = jQuery('img',html).attr('src');
			 jQuery('#upload_image').val(imgurl);
			 tb_remove();
		}
	
	});


	// Start TinyMCE
	function init() {
		tinyMCEPopup.resizeToInnerSize();
	}
	
	// Function to add the follow button to editor
	function makecode(){
		
		// Cache our form vars
		var download = document.getElementById('freebie-url').value;
		
		// If TinyMCE runable
		if(window.tinyMCE) {
			
			// Get the selected text in the editor
			selected = tinyMCE.activeEditor.selection.getContent();
			
			// Send our modified shortcode to the editor with selected content				
			window.tinyMCE.execInstanceCommand('content', 'mceInsertContent', false,  '[freebiesub download="'+download+'"]');

			// Repaints the editor
			tinyMCEPopup.editor.execCommand('mceRepaint');
			
			// Close the TinyMCE popup
			tinyMCEPopup.close();
			
		} // end if
		
		return; // always R E T U R N

	} // end add
	
</script>
</head>

<body>

<div class="tabs">
    <ul>
        <li id="pinit_tab" class="current"><span><a href="javascript:mcTabs.displayTab('pinit_tab','pinit_panel');" onmousedown="return false;">Create Form</a></span></li>
    </ul>
</div>

<div class="panel_wrapper">

    <div id="pinit_panel" class="panel current" style="height:150px !important;"><br />
    
        <form method="post" action="" id="freebieform">
                  
          <label>Download URL</label>
          <input name="freebie-url" type="text" class="input" id="freebie-url" value="" />
                    
          <input type="button" id="insert" name="insert" value="{#insert}" onclick="makecode();" />
                      
        </form>
            
    </div>

</div>

</body>
</html>