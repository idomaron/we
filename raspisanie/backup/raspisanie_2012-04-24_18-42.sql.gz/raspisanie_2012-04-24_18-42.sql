#SKD101|raspisanie|17|2012.04.24 18:42:38|99|1|3|5|4|5|6|11|2|4|4|5|32|4|4|4|5

DROP TABLE IF EXISTS `checked`;
CREATE TABLE `checked` (
  `fio_sokrat` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `predmet_sokrat` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `dop` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `okno_den` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `okno_kurs` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `okno_chas` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `okno_min` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `pechat` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `nowrap_check` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `poloska` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `mag` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `okno_check` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `vibor_check` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `povorot` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '1'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `checked` VALUES
('on', 'on', 'on', '', '', '', '', '', '', '|||', 'on', '', '', '1');

DROP TABLE IF EXISTS `dolgnost`;
CREATE TABLE `dolgnost` (
  `id_dolg` int(5) NOT NULL AUTO_INCREMENT,
  `dolgnost` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id_dolg`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `dolgnost` VALUES
(1, 'Профессор'),
(2, 'Старший преподаватель'),
(3, 'Преподаватель');

DROP TABLE IF EXISTS `dop_tabl`;
CREATE TABLE `dop_tabl` (
  `id_k_dop` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `ochered` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `dop_tabl` VALUES
('10', '1'),
('8', '3'),
('11', '4'),
('9', '6'),
('12', '8');

DROP TABLE IF EXISTS `gruppa`;
CREATE TABLE `gruppa` (
  `id_gr` int(5) NOT NULL AUTO_INCREMENT,
  `nazvanie` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `sokr_gr` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `ochered` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_gr`)
) ENGINE=MyISAM AUTO_INCREMENT=12 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `gruppa` VALUES
(1, 'Буква А', 'А', 1),
(2, 'Буква Б', 'Б', 2),
(11, 'Индивидуально', 'Инд.', 4),
(10, 'Буква В', 'В', 3);

DROP TABLE IF EXISTS `kabinet`;
CREATE TABLE `kabinet` (
  `id_k` int(5) NOT NULL AUTO_INCREMENT,
  `nomer` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `mesta` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `prim` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id_k`)
) ENGINE=MyISAM AUTO_INCREMENT=13 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `kabinet` VALUES
(10, '103', '', ''),
(8, '101', '', ''),
(11, 'Спортзал', '', ''),
(9, '102', '', ''),
(12, 'Актовый зал', '', '');

DROP TABLE IF EXISTS `klass`;
CREATE TABLE `klass` (
  `id_klass` int(5) NOT NULL AUTO_INCREMENT,
  `nazvanie` text /*!40101 CHARACTER SET utf8 */ /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `mag` text /*!40101 CHARACTER SET utf8 */ /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `ochered` varchar(50) /*!40101 CHARACTER SET utf8 */ /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id_klass`)
) ENGINE=MyISAM AUTO_INCREMENT=36 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `klass` VALUES
(1, '1й класс', '', '1'),
(2, '2й класс', '', '2'),
(3, '3й класс', '', '3'),
(4, '4й класс', '', '4'),
(5, 'Подготовишка 1', '!!', '5'),
(6, 'Подготовишка 2', '!!', '6');

DROP TABLE IF EXISTS `para`;
CREATE TABLE `para` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `vr_nach` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `para` VALUES
(1, '09:00'),
(2, '09:50'),
(3, '10:45'),
(5, '11:35'),
(6, '13:00'),
(7, '13:50'),
(8, '14:45'),
(9, '15:35'),
(10, '16:30'),
(11, '17:15'),
(12, '18:00');

DROP TABLE IF EXISTS `polezn`;
CREATE TABLE `polezn` (
  `id_str` int(5) NOT NULL AUTO_INCREMENT,
  `id_pp` int(5) NOT NULL,
  `id_k` int(5) NOT NULL,
  `id_p` int(5) NOT NULL,
  `den` int(5) NOT NULL,
  `vr_nach` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `vr_end` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `dop` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `full` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT 'false',
  `kurs` int(4) NOT NULL,
  `id_gr` int(5) NOT NULL,
  `obyed` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT 'false',
  `ochered` int(5) DEFAULT NULL,
  `vibor` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT 'false',
  PRIMARY KEY (`id_str`)
) ENGINE=MyISAM AUTO_INCREMENT=74 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `polezn` VALUES
(20, 2, 9, 3, 3, '07:00', '08:00', '', 'false', 6, 1, 'false', NULL, 'true'),
(14, 5, 11, 1, 1, '09:00', '10:35', '', 'false', 1, 1, 'false', NULL, 'false');

DROP TABLE IF EXISTS `predmet`;
CREATE TABLE `predmet` (
  `id_p` int(5) NOT NULL AUTO_INCREMENT,
  `nazvanie` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `sokrash` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `prim` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id_p`)
) ENGINE=MyISAM AUTO_INCREMENT=6 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `predmet` VALUES
(1, 'Физкультура', 'Физ-ра', ''),
(2, 'Математика', 'Мат-ика', ''),
(3, 'Русский язык', 'Рус.яз.', ''),
(4, 'Труды', 'Труд', '');

DROP TABLE IF EXISTS `prepod`;
CREATE TABLE `prepod` (
  `id_pp` int(11) NOT NULL AUTO_INCREMENT,
  `fio` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `id_dolg` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `nagruzka` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `nagruzka_tru` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `prim` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `fio_sokr` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id_pp`)
) ENGINE=MyISAM AUTO_INCREMENT=6 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `prepod` VALUES
(3, 'Иванова Юлия Владимировна', '2', '', '54000', '', 'Иванова Ю.В.'),
(1, 'Петров Петр Петрович', '1', '145', '28800', '', 'Петров П.П.'),
(2, 'Сидоров Сидр Спиридонович', '3', '', '80400', '', 'Сидоров С.С.'),
(5, 'Главный Юрий Какойнович', '1', '', '', 'Дополнительная инфа', 'Главный Ю.К.');

DROP TABLE IF EXISTS `redact`;
CREATE TABLE `redact` (
  `chto` text /*!40101 COLLATE utf8_unicode_ci */,
  `color` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '#000000',
  `bold` text /*!40101 COLLATE utf8_unicode_ci */,
  `italic` text /*!40101 COLLATE utf8_unicode_ci */,
  `font` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '1'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `redact` VALUES
('kabinet', '#4252cd', 'on', 'on', '3'),
('predmet', '#3d6f39', 'on', 'on', '3'),
('vr_nach', '#0d0c0d', 'on', '', '2'),
('vr_end', '#2c2d20', 'on', '', '2'),
('prepod', '#6f2f65', 'on', '', '3');

DROP TABLE IF EXISTS `stroka`;
CREATE TABLE `stroka` (
  `id_str` int(5) NOT NULL AUTO_INCREMENT,
  `id_pp` int(5) NOT NULL,
  `id_k` int(5) NOT NULL,
  `id_p` int(5) NOT NULL,
  `den` int(5) NOT NULL,
  `vr_nach` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `vr_end` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `dop` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `full` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT 'false',
  `kurs` int(4) NOT NULL,
  `id_gr` int(5) NOT NULL,
  `obyed` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT 'false',
  `ochered` int(5) DEFAULT NULL,
  `vibor` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT 'false',
  PRIMARY KEY (`id_str`)
) ENGINE=MyISAM AUTO_INCREMENT=49 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `stroka` VALUES
(23, 3, 2, 2, 5, '07:00', '22:00', '', 'false', 5, 10, 'false', 1, 'false'),
(24, 1, 8, 2, 5, '13:00', '14:35', '', 'false', 5, 10, 'false', 2, 'false'),
(22, 3, 2, 2, 3, '07:00', '22:00', '', 'false', 2, 2, 'false', 1, 'false'),
(20, 2, 9, 3, 3, '07:00', '08:00', '', 'false', 6, 1, 'false', 1, 'true'),
(19, 1, 10, 4, 3, '13:00', '15:00', '', 'false', 6, 1, 'false', 2, 'false'),
(18, 3, 8, 3, 1, '16:30', '18:05', '', 'false', 1, 1, 'false', 4, 'false'),
(21, 1, 8, 2, 3, '13:00', '14:35', '', 'false', 2, 2, 'false', 2, 'false'),
(14, 5, 11, 1, 1, '09:00', '10:35', '', 'false', 1, 1, 'false', 1, 'false'),
(15, 5, 11, 1, 1, '10:45', '12:20', '', 'false', 1, 1, 'false', 2, 'false'),
(16, 0, 10, 2, 1, '13:00', '14:35', 'Семинар', 'false', 1, 1, 'false', 3, 'false'),
(25, 3, 2, 2, 4, '07:00', '22:00', '', 'false', 1, 10, 'false', 1, 'false'),
(26, 1, 8, 2, 4, '13:00', '14:35', '', 'false', 1, 10, 'false', 2, 'false'),
(27, 2, 9, 3, 4, '07:00', '08:00', '', 'false', 1, 10, 'false', NULL, 'true'),
(28, 5, 11, 1, 6, '14:00', '19:00', '', 'true', 1, 11, 'false', 1, 'false'),
(29, 5, 11, 1, 6, '14:00', '19:00', '', 'true', 2, 11, 'false', 1, 'false'),
(30, 5, 11, 1, 6, '14:00', '19:00', '', 'true', 3, 11, 'false', 1, 'false'),
(31, 5, 11, 1, 6, '14:00', '19:00', '', 'false', 4, 11, 'false', 1, 'false'),
(32, 5, 11, 1, 1, '14:00', '19:00', '', 'false', 5, 11, 'false', 1, 'false'),
(33, 5, 11, 1, 2, '09:00', '10:35', '', 'false', 1, 1, 'false', 1, 'false'),
(34, 5, 11, 1, 2, '10:45', '12:20', '', 'false', 1, 1, 'false', 2, 'false'),
(35, 0, 10, 2, 2, '13:00', '14:35', 'Семинар', 'false', 1, 1, 'false', 3, 'false'),
(36, 3, 8, 3, 2, '16:30', '18:05', '', 'false', 1, 1, 'false', 4, 'false'),
(37, 2, 9, 3, 2, '07:00', '08:00', '', 'false', 3, 1, 'false', 1, 'true'),
(38, 1, 10, 4, 2, '13:00', '15:00', '', 'false', 3, 1, 'false', 2, 'false'),
(39, 2, 9, 3, 2, '07:00', '08:00', '', 'true', 4, 1, 'false', 1, 'true'),
(40, 1, 10, 4, 2, '13:00', '15:00', '', 'true', 4, 1, 'false', 2, 'false'),
(41, 1, 9, 4, 4, '12:00', '13:35', '', 'false', 4, 2, 'false', NULL, 'false'),
(42, 3, 9, 4, 4, '12:00', '13:35', '', 'false', 4, 2, 'true', NULL, 'false'),
(43, 2, 10, 1, 4, '15:00', '17:30', '', 'false', 4, 2, 'false', NULL, 'false'),
(46, 5, 11, 3, 4, '06:00', '08:00', '', 'false', 4, 2, 'false', NULL, 'false'),
(47, 3, 2, 2, 2, '07:00', '22:00', '', 'false', 5, 1, 'false', 1, 'false'),
(48, 1, 8, 2, 2, '13:00', '14:35', '', 'false', 5, 1, 'false', 2, 'false');

DROP TABLE IF EXISTS `stroka_2`;
CREATE TABLE `stroka_2` (
  `id_str` int(5) NOT NULL,
  `id_pp` int(5) NOT NULL,
  `id_k` int(5) NOT NULL,
  `id_p` int(5) NOT NULL,
  `den` int(5) NOT NULL,
  `vr_nach` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `vr_end` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `dop` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `full` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `kurs` int(4) NOT NULL,
  `id_gr` int(5) NOT NULL,
  `obyed` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `ochered` int(5) DEFAULT NULL,
  `vibor` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT 'false'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

DROP TABLE IF EXISTS `table_head_kabinet`;
CREATE TABLE `table_head_kabinet` (
  `header1` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `header2` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `header3` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `header4` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `table_head_kabinet` VALUES
('Номер кабинета', 'Вместимость', 'Примечание', 'Удалить'),
('Номер кабинета', 'Вместимость', 'Примечание', 'Удалить'),
('Номер кабинета', 'Вместимость', 'Примечание', 'Удалить'),
('Номер кабинета', 'Вместимость', 'Примечание', 'Удалить');

DROP TABLE IF EXISTS `table_head_predmet`;
CREATE TABLE `table_head_predmet` (
  `header1` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `header2` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `header3` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `header4` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `table_head_predmet` VALUES
('Предмет', 'Сокращённый', 'Примечание', 'Удалить'),
('Предмет', 'Сокращённый', 'Примечание', 'Удалить'),
('Предмет', 'Сокращённый', 'Примечание', 'Удалить'),
('Предмет', 'Сокращённый', 'Примечание', 'Удалить');

DROP TABLE IF EXISTS `table_head_prepod`;
CREATE TABLE `table_head_prepod` (
  `header1` text /*!40101 COLLATE utf8_unicode_ci */,
  `header2` text /*!40101 COLLATE utf8_unicode_ci */,
  `header3` text /*!40101 COLLATE utf8_unicode_ci */,
  `header4` text /*!40101 COLLATE utf8_unicode_ci */,
  `header5` text /*!40101 COLLATE utf8_unicode_ci */,
  `header6` text /*!40101 COLLATE utf8_unicode_ci */,
  `header7` text /*!40101 COLLATE utf8_unicode_ci */
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `table_head_prepod` VALUES
('Фио', 'Должность', 'Ф.И.О.', 'Нагрузка (должна быть)', 'Нагрузка есть', 'Примечание', 'Удалить'),
('Фио', 'Должность', 'Ф.И.О.', 'Нагрузка (должна быть)', 'Нагрузка есть', 'Примечание', 'Удалить'),
('Фио', 'Должность', 'Ф.И.О.', 'Нагрузка (должна быть)', 'Нагрузка есть', 'Примечание', 'Удалить'),
('Фио', 'Должность', 'Ф.И.О.', 'Нагрузка (должна быть)', 'Нагрузка есть', 'Примечание', 'Удалить');

DROP TABLE IF EXISTS `time_polezn`;
CREATE TABLE `time_polezn` (
  `id_time` int(11) NOT NULL AUTO_INCREMENT,
  `vr_nach` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `vr_end` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id_time`)
) ENGINE=MyISAM AUTO_INCREMENT=6 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `time_polezn` VALUES
(1, '09:00', '10:35'),
(2, '10:45', '12:20'),
(3, '13:00', '14:35'),
(4, '14:45', '16:20'),
(5, '16:30', '18:05');

